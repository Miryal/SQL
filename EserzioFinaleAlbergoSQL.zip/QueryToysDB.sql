-- CREAZIONE DEL DATABASE
CREATE DATABASE ToysGroupDB;
USE ToysGroupDB;

-- CREAZIONE TABELLA CATEGORIES
CREATE TABLE Categories (CategoryID INTEGER PRIMARY KEY,
Nome VARCHAR(50));

-- CREAZIONE TABELLA PRODUCTS
CREATE TABLE Products (ProductID INTEGER PRIMARY KEY,
CategoryID INTEGER,
Nome VARCHAR(50),
Prezzo FLOAT,
FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID));

-- CREAZIONE DELLA TABELLA REGIONS
CREATE TABLE Regions (RegionID INTEGER PRIMARY KEY,
Nome VARCHAR(30));

-- CREAZIONE TABELLA COUNTRIES
CREATE TABLE Countries (CountryID INTEGER PRIMARY KEY,
Nome VARCHAR(30),
RegionID INTEGER,
FOREIGN KEY (RegionID) REFERENCES Regions(RegionID));

-- CREAZIONE TABELLA SALES
CREATE TABLE Sales (SalesID INTEGER PRIMARY KEY,
Data DATE,
ProductID INTEGER,
Prezzo FLOAT,
Quantità INTEGER,
CountryID INTEGER,
FOREIGN KEY (ProductID) REFERENCES Products(ProductID),
FOREIGN KEY (CountryID) REFERENCES Countries(CountryID));


-- INSERIMENTO DATI NELLA TABELLA CATEGORIES 
INSERT INTO CATEGORIES (CategoryID, Nome) VALUES
(1, 'Bambole'),
(2, 'Macchinine'),
(3, 'Puzzle'),
(4, 'Peluche'),
(5, 'Giochi da tavolo'),
(6, 'Costruzioni');

-- INSERIMENTO DATI NELLA TABELLA PRODUCTS 
INSERT INTO PRODUCTS (ProductID, Nome, CategoryID, Prezzo) VALUES
(1, 'Barbie', 1, 19.99),
(2, 'Hot Wheels', 2, 7.99),
(3, 'Puzzle Disney', 3, 12.99),
(4, 'Orsetto di peluche', 4, 14.99),
(5, 'Monopoli', 5, 29.99),
(6, 'LEGO Classic', 6, 39.99),
(7, 'Macchinina telecomandata', 2, 24.99),
(8, 'Bambola di pezza', 1, 9.99),
(9, 'Set di costruzioni in legno', 6, 19.99),
(10, 'Puzzle paesaggio', 3, 8.99);

-- INSERIMENTO DATI NELLA TABELLA REGIONS 
INSERT INTO REGIONS (RegionID, Nome) VALUES
(1, 'WestEurope'),
(2, 'SouthEurope'),
(3, 'NorthEurope'),
(4, 'EastEurope'),
(5, 'CentralEurope');

-- INSERIMENTO DATI NELLA TABELLA COUNTRIES
INSERT INTO COUNTRIES (CountryID, Nome, RegionID) VALUES
(1, 'Italia', 2),
(2, 'Francia', 1),
(3, 'Spagna', 2),
(4, 'Germania', 1),
(5, 'Portogallo', 2),
(6, 'Grecia', 2),
(7, 'Olanda', 1),
(8, 'Regno Unito', 1),
(9, 'Svezia', 3),
(10, 'Norvegia', 3),
(11, 'Polonia', 4),
(12, 'Romania', 4),
(13, 'Austria', 5),
(14, 'Svizzera', 5);

-- INSERIMENTO DATI NELLA TABELLA SALES 
INSERT INTO SALES (SalesID, Data, ProductID, Prezzo, Quantità, CountryID) VALUES
(1, '2019-02-10', 1, 19.99, 1, 1),
(2, '2019-04-15', 2, 7.99, 2, 2),
(3, '2019-06-20', 3, 12.99, 1, 3),
(4, '2019-08-25', 4, 14.99, 3, 4),
(5, '2019-10-30', 5, 29.99, 1, 5),
(6, '2019-12-05', 6, 39.99, 2, 6),
(7, '2020-02-10', 7, 24.99, 1, 7),
(8, '2020-04-15', 8, 9.99, 2, 1),
(9, '2020-06-20', 9, 19.99, 1, 2),
(10, '2020-08-25', 10, 8.99, 3, 3),
(11, '2020-10-30', 1, 19.99, 1, 4),
(12, '2020-12-05', 2, 7.99, 2, 5),
(13, '2021-02-10', 3, 12.99, 1, 6),
(14, '2021-04-15', 4, 14.99, 3, 7),
(15, '2021-06-20', 5, 29.99, 1, 1),
(16, '2021-08-25', 6, 39.99, 2, 2),
(17, '2021-10-30', 7, 24.99, 1, 3),
(18, '2021-12-05', 8, 9.99, 2, 4),
(19, '2022-02-10', 9, 19.99, 1, 5),
(20, '2022-04-15', 10, 8.99, 3, 6),
(21, '2022-06-20', 1, 19.99, 1, 7),
(22, '2022-08-25', 2, 7.99, 2, 1),
(23, '2022-10-30', 3, 12.99, 1, 2),
(24, '2022-12-05', 4, 14.99, 3, 3),
(25, '2023-02-10', 5, 29.99, 1, 4),
(26, '2023-04-15', 6, 39.99, 2, 5),
(27, '2023-06-20', 7, 24.99, 1, 6),
(28, '2023-08-25', 8, 9.99, 2, 7),
(29, '2023-10-30', 9, 19.99, 1, 1),
(30, '2023-12-05', 10, 8.99, 3, 2);

-- VERIFICA UNICITA' DELLA PK TABELLA CATEGORIES
SELECT CategoryID, COUNT(*)
FROM CATEGORIES
GROUP BY CategoryID
HAVING COUNT(*) > 1;

-- VERIFICA UNICITA' DELLA PK TABELLA PRODUCTS
SELECT ProductID, COUNT(*)
FROM PRODUCTS
GROUP BY ProductID
HAVING COUNT(*) > 1;

-- VERIFICA UNICITA' DELLA PK TABELLA REGIONS
SELECT RegionID, COUNT(*)
FROM REGIONS
GROUP BY RegionID
HAVING COUNT(*) > 1;

-- VERIFICA UNICITA' DELLA PK TABELLA COUNTRIES
SELECT CountryID, COUNT(*)
FROM COUNTRIES
GROUP BY CountryID
HAVING COUNT(*) > 1;

-- VERIFICA UNICITA' DELLA PK TABELLA SALES
SELECT SalesID, COUNT(*)
FROM SALES
GROUP BY SalesID
HAVING COUNT(*) > 1;

-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.  
SELECT p.Nome AS NomeProdotto, 
YEAR(s.Data) AS AnnoVendita, 
SUM(s.Prezzo * s.Quantità) AS FatturatoTotale
FROM SALES s
JOIN PRODUCTS p ON s.ProductID = p.ProductID
GROUP BY p.Nome, YEAR(s.Data)
ORDER BY p.Nome, YEAR(s.Data);

-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 
SELECT c.Nome AS NomeStato,
YEAR(s.Data) AS Anno,
SUM(s.Prezzo * s.Quantità) AS FatturatoTotale
FROM COUNTRIES c
JOIN SALES s ON c.CountryID = s.CountryID
GROUP BY c.Nome, YEAR(s.Data)
ORDER BY YEAR(s.Data) ASC, FatturatoTotale DESC;

-- qual è la categoria di articoli maggiormente richiesta dal mercato? 
SELECT c.Nome AS Categoria, SUM(s.Quantità) AS QuantitàTotale
FROM SALES s
JOIN PRODUCTS p ON s.ProductID = p.ProductID
JOIN CATEGORIES c ON p.CategoryID = c.CategoryID
GROUP BY c.Nome
ORDER BY QuantitàTotale DESC
LIMIT 1;

--  quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.
SELECT *
FROM PRODUCTS
WHERE ProductID NOT IN (SELECT DISTINCT ProductID FROM SALES);

-- oppure
SELECT p.*
FROM PRODUCTS p
LEFT JOIN SALES s ON p.ProductID = s.ProductID
WHERE s.ProductID IS NULL;

-- Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
SELECT p.Nome AS Prodotto, MAX(s.Data) AS UltimaDataVendita
FROM PRODUCTS p
LEFT JOIN SALES s ON p.ProductID = s.ProductID
GROUP BY p.Nome;

-- BONUS: Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)
SELECT s.SalesID AS CodiceDocumento,
s.Data AS DataVendita,
p.Nome AS NomeProdotto,
c.Nome AS CategoriaProdotto,
co.Nome AS NomeStato,
r.Nome AS NomeRegione,
CASE WHEN DATEDIFF(CURRENT_DATE(), s.Data) > 180 THEN TRUE ELSE FALSE
END AS Passati180Giorni
FROM SALES s
JOIN PRODUCTS p ON s.ProductID = p.ProductID
JOIN CATEGORIES c ON p.CategoryID = c.CategoryID
JOIN COUNTRIES co ON s.CountryID = co.CountryID
JOIN REGIONS r ON co.RegionID = r.RegionID;





